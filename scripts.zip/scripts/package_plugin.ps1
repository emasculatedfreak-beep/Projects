param(
    [string]$PluginFolder = "gee_data_fetcher",
    [string]$OutputDir = "dist"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$pluginPath = Join-Path $root $PluginFolder

if (-not (Test-Path $pluginPath)) {
    throw "Plugin folder not found: $pluginPath"
}

$metadataPath = Join-Path $pluginPath "metadata.txt"
if (-not (Test-Path $metadataPath)) {
    throw "metadata.txt not found in $pluginPath"
}

$versionLine = Select-String -Path $metadataPath -Pattern '^version=' | Select-Object -First 1
if (-not $versionLine) {
    throw "version field not found in metadata.txt"
}

$version = $versionLine.Line.Split('=')[1].Trim()
$distPath = Join-Path $root $OutputDir
New-Item -ItemType Directory -Path $distPath -Force | Out-Null

$stagingPath = Join-Path $distPath "${PluginFolder}_staging"
if (Test-Path $stagingPath) {
    Remove-Item -Recurse -Force $stagingPath
}

New-Item -ItemType Directory -Path $stagingPath -Force | Out-Null
$stagedPluginPath = Join-Path $stagingPath $PluginFolder
New-Item -ItemType Directory -Path $stagedPluginPath -Force | Out-Null

Copy-Item -Path (Join-Path $pluginPath '*') -Destination $stagedPluginPath -Recurse -Force

Get-ChildItem -Path $stagedPluginPath -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
Get-ChildItem -Path $stagedPluginPath -Recurse -Include *.pyc,*.pyo | Remove-Item -Force

$zipPath = Join-Path $distPath "${PluginFolder}-${version}.zip"
if (Test-Path $zipPath) {
    Remove-Item -Force $zipPath
}

Compress-Archive -Path (Join-Path $stagingPath '*') -DestinationPath $zipPath
Remove-Item -Recurse -Force $stagingPath

Write-Host "Created package: $zipPath"
