def classFactory(iface):
    try:
        from .plugin import GeeDataFetcherPlugin
    except (ImportError, KeyError):
        from plugin import GeeDataFetcherPlugin

    return GeeDataFetcherPlugin(iface)
