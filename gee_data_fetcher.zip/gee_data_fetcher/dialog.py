import os

from qgis.PyQt.QtCore import QDate, QSettings, Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

try:
    from .dataset_presets import (
        PRESETS,
        PRESET_LOOKUP,
        get_band_labels,
        get_output_band_names,
        split_bands,
    )
    from .gee_service import DownloadRequest, build_code_preview
except (ImportError, KeyError):
    from dataset_presets import (
        PRESETS,
        PRESET_LOOKUP,
        get_band_labels,
        get_output_band_names,
        split_bands,
    )
    from gee_service import DownloadRequest, build_code_preview


class GeeDataFetcherDialog(QDialog):
    SETTINGS_PREFIX = "gee_data_fetcher"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._busy = False
        self.setWindowTitle("GEE Data Fetcher")
        self.resize(820, 760)

        self._build_ui()
        self._wire_signals()
        self._load_settings()
        self._apply_preset(self.dataset_preset_combo.currentText(), keep_custom_values=True)
        self.update_code_preview()

    def _build_ui(self):
        root_layout = QVBoxLayout(self)

        intro = QLabel(
            "Choose an Earth Engine dataset, a time range, a region of interest, and an output GeoTIFF. "
            "The plugin will generate the request, download the raster, and add it to QGIS."
        )
        intro.setWordWrap(True)
        root_layout.addWidget(intro)

        earth_engine_group = QGroupBox("Earth Engine Request")
        ee_form = QFormLayout(earth_engine_group)

        self.project_id_edit = QLineEdit()
        self.project_id_edit.setPlaceholderText("your-google-cloud-project-id")
        ee_form.addRow("Cloud project", self.project_id_edit)

        self.dataset_preset_combo = QComboBox()
        self.dataset_preset_combo.addItems([preset.label for preset in PRESETS])
        ee_form.addRow("Preset", self.dataset_preset_combo)

        self.dataset_id_edit = QLineEdit()
        self.dataset_id_edit.setPlaceholderText("COPERNICUS/S2_SR_HARMONIZED")
        ee_form.addRow("Dataset ID", self.dataset_id_edit)

        self.source_type_combo = QComboBox()
        self.source_type_combo.addItems(["ImageCollection", "Image"])
        ee_form.addRow("Source type", self.source_type_combo)

        self.bands_edit = QLineEdit()
        self.bands_edit.setPlaceholderText("B4,B3,B2")
        ee_form.addRow("Bands", self.bands_edit)

        date_row = QWidget()
        date_layout = QHBoxLayout(date_row)
        date_layout.setContentsMargins(0, 0, 0, 0)

        self.start_date_edit = QDateEdit()
        self.start_date_edit.setCalendarPopup(True)
        self.start_date_edit.setDate(QDate.currentDate().addMonths(-1))
        date_layout.addWidget(self.start_date_edit)

        self.end_date_edit = QDateEdit()
        self.end_date_edit.setCalendarPopup(True)
        self.end_date_edit.setDate(QDate.currentDate())
        date_layout.addWidget(QLabel("to"))
        date_layout.addWidget(self.end_date_edit)
        ee_form.addRow("Date range", date_row)

        self.reducer_combo = QComboBox()
        self.reducer_combo.addItems(["median", "mean", "mosaic", "mode", "first"])
        ee_form.addRow("Reducer", self.reducer_combo)

        self.scale_spin = QSpinBox()
        self.scale_spin.setRange(1, 10000)
        self.scale_spin.setValue(10)
        self.scale_spin.setSuffix(" m")
        ee_form.addRow("Scale", self.scale_spin)

        self.region_source_combo = QComboBox()
        self.region_source_combo.addItems(
            ["Current map canvas extent", "Selected polygons from active layer"]
        )
        ee_form.addRow("Region source", self.region_source_combo)

        self.format_label = QLabel("GeoTIFF")
        ee_form.addRow("Output format", self.format_label)

        self.preset_description_label = QLabel("")
        self.preset_description_label.setWordWrap(True)
        self.preset_description_label.setStyleSheet("color: #555;")
        ee_form.addRow("Preset notes", self.preset_description_label)

        root_layout.addWidget(earth_engine_group)

        output_group = QGroupBox("Output")
        output_form = QFormLayout(output_group)

        output_row = QWidget()
        output_layout = QHBoxLayout(output_row)
        output_layout.setContentsMargins(0, 0, 0, 0)

        self.output_path_edit = QLineEdit()
        output_layout.addWidget(self.output_path_edit)

        self.browse_button = QPushButton("Browse")
        output_layout.addWidget(self.browse_button)
        output_form.addRow("GeoTIFF path", output_row)

        self.layer_name_edit = QLineEdit()
        self.layer_name_edit.setPlaceholderText("Layer name in QGIS")
        output_form.addRow("Layer name", self.layer_name_edit)

        self.load_individual_bands_checkbox = QCheckBox("Also add single-band analysis layers")
        self.load_individual_bands_checkbox.setChecked(True)
        output_form.addRow("", self.load_individual_bands_checkbox)

        root_layout.addWidget(output_group)

        preview_group = QGroupBox("Generated Earth Engine Code")
        preview_layout = QVBoxLayout(preview_group)
        self.code_preview = QPlainTextEdit()
        self.code_preview.setReadOnly(True)
        self.code_preview.setLineWrapMode(QPlainTextEdit.NoWrap)
        preview_layout.addWidget(self.code_preview)
        root_layout.addWidget(preview_group, 1)

        self.status_label = QLabel("Ready.")
        self.status_label.setWordWrap(True)
        self.status_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        root_layout.addWidget(self.status_label)

        button_row = QWidget()
        button_layout = QHBoxLayout(button_row)
        button_layout.setContentsMargins(0, 0, 0, 0)

        self.authenticate_button = QPushButton("Authenticate")
        button_layout.addWidget(self.authenticate_button)

        self.download_button = QPushButton("Download and Add to QGIS")
        button_layout.addWidget(self.download_button)

        self.close_button = QPushButton("Close")
        button_layout.addWidget(self.close_button)
        root_layout.addWidget(button_row)

    def _wire_signals(self):
        self.dataset_preset_combo.currentTextChanged.connect(self._apply_preset)
        self.browse_button.clicked.connect(self._browse_output_path)
        self.close_button.clicked.connect(self.reject)

        watched_widgets = [
            self.project_id_edit,
            self.dataset_id_edit,
            self.bands_edit,
            self.layer_name_edit,
            self.output_path_edit,
        ]
        for widget in watched_widgets:
            widget.textChanged.connect(self.update_code_preview)

        self.source_type_combo.currentTextChanged.connect(self._update_date_controls)
        self.source_type_combo.currentTextChanged.connect(self.update_code_preview)
        self.reducer_combo.currentTextChanged.connect(self.update_code_preview)
        self.region_source_combo.currentTextChanged.connect(self.update_code_preview)
        self.start_date_edit.dateChanged.connect(self.update_code_preview)
        self.end_date_edit.dateChanged.connect(self.update_code_preview)
        self.scale_spin.valueChanged.connect(self.update_code_preview)
        self.load_individual_bands_checkbox.toggled.connect(self.update_code_preview)

    def _apply_preset(self, preset_label: str, keep_custom_values: bool = False):
        preset = PRESET_LOOKUP[preset_label]
        self.preset_description_label.setText(preset.description)

        if preset.label != "Custom" or not keep_custom_values:
            if preset.dataset_id:
                self.dataset_id_edit.setText(preset.dataset_id)
            self.source_type_combo.setCurrentText(preset.source_type)
            self.bands_edit.setText(preset.default_bands)
            self.reducer_combo.setCurrentText(preset.default_reducer)
            self.scale_spin.setValue(preset.default_scale)

        self.dataset_id_edit.setReadOnly(preset.label != "Custom")
        self._update_date_controls()
        self._update_output_suggestion()
        self.update_code_preview()

    def _update_date_controls(self):
        preset = PRESET_LOOKUP[self.dataset_preset_combo.currentText()]
        source_type = self.source_type_combo.currentText()
        uses_dates = source_type == "ImageCollection" and preset.supports_date_range
        self.start_date_edit.setEnabled(uses_dates)
        self.end_date_edit.setEnabled(uses_dates)

    def _update_output_suggestion(self):
        if self.output_path_edit.text().strip():
            return

        home_dir = os.path.expanduser("~")
        safe_name = (
            self.dataset_id_edit.text().strip().replace("/", "_").replace(":", "_") or "gee_download"
        )
        default_name = "{}_{}.tif".format(
            safe_name,
            QDate.currentDate().toString("yyyyMMdd"),
        )
        self.output_path_edit.setText(os.path.join(home_dir, default_name))

        if not self.layer_name_edit.text().strip():
            self.layer_name_edit.setText(safe_name)

    def _browse_output_path(self):
        current_path = self.output_path_edit.text().strip() or os.path.expanduser("~")
        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Choose GeoTIFF output",
            current_path,
            "GeoTIFF (*.tif *.tiff)",
        )
        if output_path:
            if not output_path.lower().endswith((".tif", ".tiff")):
                output_path = "{}.tif".format(output_path)
            self.output_path_edit.setText(output_path)
            if not self.layer_name_edit.text().strip():
                self.layer_name_edit.setText(os.path.splitext(os.path.basename(output_path))[0])

    def update_code_preview(self):
        try:
            draft_request = self.build_request(region_geojson=None, for_preview=True)
        except ValueError as exc:
            self.code_preview.setPlainText(
                "Fill in the required fields to preview the Earth Engine code.\n\n{}".format(exc)
            )
            return

        self.code_preview.setPlainText(build_code_preview(draft_request))

    def build_request(self, region_geojson, for_preview: bool = False) -> DownloadRequest:
        project_id = self.project_id_edit.text().strip()
        dataset_id = self.dataset_id_edit.text().strip()
        preset_label = self.dataset_preset_combo.currentText().strip()
        source_type = self.source_type_combo.currentText().strip()
        region_label = self.region_source_combo.currentText().strip()
        output_path = self.output_path_edit.text().strip()
        layer_name = self.layer_name_edit.text().strip()
        source_bands = split_bands(self.bands_edit.text())
        output_bands = get_output_band_names(preset_label, source_bands)
        band_labels = get_band_labels(preset_label, dataset_id, source_bands)

        if not dataset_id:
            raise ValueError("Dataset ID is required.")
        if not project_id:
            raise ValueError("Cloud project is required.")
        if not output_path and not for_preview:
            raise ValueError("Output GeoTIFF path is required.")
        if PRESET_LOOKUP[preset_label].derived_product and len(source_bands) != 2:
            raise ValueError(
                "{} requires exactly two source bands.".format(
                    PRESET_LOOKUP[preset_label].derived_product
                )
            )

        if not output_path:
            output_path = os.path.join(os.path.expanduser("~"), "gee_download.tif")
        if not layer_name:
            layer_name = os.path.splitext(os.path.basename(output_path))[0]

        uses_dates = self.start_date_edit.isEnabled() and self.end_date_edit.isEnabled()
        start_date = self.start_date_edit.date().toString("yyyy-MM-dd") if uses_dates else None
        end_date = self.end_date_edit.date().toString("yyyy-MM-dd") if uses_dates else None

        if uses_dates and self.start_date_edit.date() > self.end_date_edit.date():
            raise ValueError("Start date must be before or equal to end date.")

        return DownloadRequest(
            project_id=project_id,
            preset_label=preset_label,
            dataset_id=dataset_id,
            source_type=source_type,
            source_bands=source_bands,
            output_bands=output_bands,
            band_labels=band_labels,
            derived_product=PRESET_LOOKUP[preset_label].derived_product,
            start_date=start_date,
            end_date=end_date,
            reducer=self.reducer_combo.currentText().strip(),
            scale=self.scale_spin.value(),
            region_geojson=region_geojson,
            region_label=region_label,
            output_path=output_path,
            layer_name=layer_name,
            load_individual_bands=self.load_individual_bands_checkbox.isChecked(),
        )

    def save_settings(self):
        settings = QSettings()
        settings.setValue("{}/project_id".format(self.SETTINGS_PREFIX), self.project_id_edit.text().strip())
        settings.setValue("{}/dataset_preset".format(self.SETTINGS_PREFIX), self.dataset_preset_combo.currentText())
        settings.setValue("{}/dataset_id".format(self.SETTINGS_PREFIX), self.dataset_id_edit.text().strip())
        settings.setValue("{}/source_type".format(self.SETTINGS_PREFIX), self.source_type_combo.currentText())
        settings.setValue("{}/bands".format(self.SETTINGS_PREFIX), self.bands_edit.text().strip())
        settings.setValue("{}/start_date".format(self.SETTINGS_PREFIX), self.start_date_edit.date().toString("yyyy-MM-dd"))
        settings.setValue("{}/end_date".format(self.SETTINGS_PREFIX), self.end_date_edit.date().toString("yyyy-MM-dd"))
        settings.setValue("{}/reducer".format(self.SETTINGS_PREFIX), self.reducer_combo.currentText())
        settings.setValue("{}/scale".format(self.SETTINGS_PREFIX), self.scale_spin.value())
        settings.setValue("{}/region_source".format(self.SETTINGS_PREFIX), self.region_source_combo.currentText())
        settings.setValue("{}/output_path".format(self.SETTINGS_PREFIX), self.output_path_edit.text().strip())
        settings.setValue("{}/layer_name".format(self.SETTINGS_PREFIX), self.layer_name_edit.text().strip())
        settings.setValue(
            "{}/load_individual_bands".format(self.SETTINGS_PREFIX),
            self.load_individual_bands_checkbox.isChecked(),
        )

    def set_status(self, message: str, is_error: bool = False):
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: {};".format("#b42318" if is_error else "#1f2937"))

    def set_busy(self, busy: bool):
        self._busy = busy
        self.authenticate_button.setEnabled(not busy)
        self.download_button.setEnabled(not busy)
        self.close_button.setEnabled(not busy)

    def show_error(self, message: str):
        QMessageBox.critical(self, "GEE Data Fetcher", message)
        self.set_status(message, is_error=True)

    def reject(self):
        if self._busy:
            self.set_status("Wait for the active Earth Engine task to finish before closing.", is_error=True)
            return
        super().reject()

    def _load_settings(self):
        settings = QSettings()
        dataset_preset = settings.value("{}/dataset_preset".format(self.SETTINGS_PREFIX), PRESETS[0].label)

        self.project_id_edit.setText(settings.value("{}/project_id".format(self.SETTINGS_PREFIX), ""))
        preset_index = self.dataset_preset_combo.findText(dataset_preset)
        if preset_index >= 0:
            self.dataset_preset_combo.setCurrentIndex(preset_index)
        self.dataset_id_edit.setText(settings.value("{}/dataset_id".format(self.SETTINGS_PREFIX), ""))
        self.source_type_combo.setCurrentText(
            settings.value("{}/source_type".format(self.SETTINGS_PREFIX), "ImageCollection")
        )
        self.bands_edit.setText(settings.value("{}/bands".format(self.SETTINGS_PREFIX), ""))

        start_date = settings.value("{}/start_date".format(self.SETTINGS_PREFIX), "")
        if start_date:
            self.start_date_edit.setDate(QDate.fromString(start_date, "yyyy-MM-dd"))

        end_date = settings.value("{}/end_date".format(self.SETTINGS_PREFIX), "")
        if end_date:
            self.end_date_edit.setDate(QDate.fromString(end_date, "yyyy-MM-dd"))

        reducer = settings.value("{}/reducer".format(self.SETTINGS_PREFIX), "median")
        if self.reducer_combo.findText(reducer) >= 0:
            self.reducer_combo.setCurrentText(reducer)

        self.scale_spin.setValue(int(settings.value("{}/scale".format(self.SETTINGS_PREFIX), 10)))

        region_source = settings.value(
            "{}/region_source".format(self.SETTINGS_PREFIX),
            "Current map canvas extent",
        )
        if self.region_source_combo.findText(region_source) >= 0:
            self.region_source_combo.setCurrentText(region_source)

        self.output_path_edit.setText(settings.value("{}/output_path".format(self.SETTINGS_PREFIX), ""))
        self.layer_name_edit.setText(settings.value("{}/layer_name".format(self.SETTINGS_PREFIX), ""))
        self.load_individual_bands_checkbox.setChecked(
            settings.value("{}/load_individual_bands".format(self.SETTINGS_PREFIX), True, type=bool)
        )
