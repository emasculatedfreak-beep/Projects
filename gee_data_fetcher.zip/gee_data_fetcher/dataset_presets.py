from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class DatasetPreset:
    label: str
    dataset_id: str
    source_type: str
    default_bands: str
    default_reducer: str
    default_scale: int
    supports_date_range: bool
    description: str
    derived_product: str = ""


PRESETS = [
    DatasetPreset(
        label="Sentinel-2 Surface Reflectance",
        dataset_id="COPERNICUS/S2_SR_HARMONIZED",
        source_type="ImageCollection",
        default_bands="B4,B3,B2",
        default_reducer="median",
        default_scale=10,
        supports_date_range=True,
        description="Good default for true-color optical imagery at 10 m.",
    ),
    DatasetPreset(
        label="Sentinel-2 NDVI",
        dataset_id="COPERNICUS/S2_SR_HARMONIZED",
        source_type="ImageCollection",
        default_bands="B8,B4",
        default_reducer="median",
        default_scale=10,
        supports_date_range=True,
        description="One-click vegetation index output. Uses normalized difference of NIR and red bands.",
        derived_product="NDVI",
    ),
    DatasetPreset(
        label="Sentinel-2 NDWI",
        dataset_id="COPERNICUS/S2_SR_HARMONIZED",
        source_type="ImageCollection",
        default_bands="B3,B8",
        default_reducer="median",
        default_scale=10,
        supports_date_range=True,
        description="One-click water index output. Uses normalized difference of green and NIR bands.",
        derived_product="NDWI",
    ),
    DatasetPreset(
        label="Landsat 8 Collection 2 TOA",
        dataset_id="LANDSAT/LC08/C02/T1_TOA",
        source_type="ImageCollection",
        default_bands="B4,B3,B2",
        default_reducer="median",
        default_scale=30,
        supports_date_range=True,
        description="Broader temporal archive with 30 m optical bands.",
    ),
    DatasetPreset(
        label="NASADEM Elevation",
        dataset_id="NASA/NASADEM_HGT/001",
        source_type="Image",
        default_bands="elevation",
        default_reducer="first",
        default_scale=30,
        supports_date_range=False,
        description="Static elevation model. Date filters are not used.",
    ),
    DatasetPreset(
        label="Dynamic World Land Cover",
        dataset_id="GOOGLE/DYNAMICWORLD/V1",
        source_type="ImageCollection",
        default_bands="label",
        default_reducer="mode",
        default_scale=10,
        supports_date_range=True,
        description="Near-real-time land cover classes derived from Sentinel-2.",
    ),
    DatasetPreset(
        label="Custom",
        dataset_id="",
        source_type="ImageCollection",
        default_bands="",
        default_reducer="median",
        default_scale=10,
        supports_date_range=True,
        description="Enter any Earth Engine image or image collection ID.",
    ),
]


PRESET_LOOKUP = {preset.label: preset for preset in PRESETS}


BAND_ALIASES = {
    "COPERNICUS/S2_SR_HARMONIZED": {
        "B2": "Blue",
        "B3": "Green",
        "B4": "Red",
        "B8": "NIR",
        "B11": "SWIR1",
        "B12": "SWIR2",
    },
    "LANDSAT/LC08/C02/T1_TOA": {
        "B2": "Blue",
        "B3": "Green",
        "B4": "Red",
        "B5": "NIR",
        "B6": "SWIR1",
        "B7": "SWIR2",
    },
    "NASA/NASADEM_HGT/001": {
        "elevation": "Elevation",
    },
    "GOOGLE/DYNAMICWORLD/V1": {
        "label": "Land Cover Class",
    },
}


def split_bands(text: str) -> List[str]:
    return [band.strip() for band in text.split(",") if band.strip()]


def get_output_band_names(preset_label: str, source_bands: List[str]) -> List[str]:
    preset = PRESET_LOOKUP[preset_label]
    if preset.derived_product:
        return [preset.derived_product]
    return source_bands


def get_band_labels(preset_label: str, dataset_id: str, source_bands: List[str]) -> List[str]:
    preset = PRESET_LOOKUP[preset_label]
    if preset.derived_product:
        return [preset.derived_product]

    aliases = BAND_ALIASES.get(dataset_id, {})
    labels = []
    for band in source_bands:
        alias = aliases.get(band)
        if alias and alias.lower() != band.lower():
            labels.append("{} ({})".format(alias, band))
        elif alias:
            labels.append(alias)
        else:
            labels.append(band)
    return labels
