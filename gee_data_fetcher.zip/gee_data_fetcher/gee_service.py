import json
import os
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional


ProgressCallback = Optional[Callable[[float], None]]
CancelCallback = Optional[Callable[[], bool]]


@dataclass
class DownloadRequest:
    project_id: str
    preset_label: str
    dataset_id: str
    source_type: str
    source_bands: List[str]
    output_bands: List[str]
    band_labels: List[str]
    derived_product: str
    start_date: Optional[str]
    end_date: Optional[str]
    reducer: str
    scale: int
    region_geojson: Optional[Dict[str, Any]]
    region_label: str
    output_path: str
    layer_name: str
    load_individual_bands: bool


@dataclass
class GeneratedLayer:
    path: str
    name: str


@dataclass
class DownloadResult:
    output_path: str
    load_path: str
    layer_name: str
    generated_layers: List[GeneratedLayer]


def _set_progress(progress_callback: ProgressCallback, value: float) -> None:
    if progress_callback:
        progress_callback(value)


def _check_cancel(cancel_callback: CancelCallback) -> None:
    if cancel_callback and cancel_callback():
        raise RuntimeError("Download cancelled.")


def ensure_earth_engine():
    try:
        import ee  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "The Earth Engine Python API is not installed in the QGIS Python environment. "
            "Install it with 'python -m pip install earthengine-api' using the same Python that QGIS uses."
        ) from exc

    return ee


def authenticate(project_id: str) -> None:
    ee = ensure_earth_engine()

    if not project_id:
        raise RuntimeError("An Earth Engine Cloud project ID is required.")

    try:
        ee.Initialize(project=project_id)
    except Exception:
        ee.Authenticate()
        ee.Initialize(project=project_id)


def build_code_preview(request: DownloadRequest) -> str:
    if request.region_geojson:
        region_lines = [
            "region = ee.Geometry({})".format(
                json.dumps(request.region_geojson, indent=4, sort_keys=True)
            )
        ]
    else:
        region_lines = [
            "# Region is resolved at runtime from: {}".format(request.region_label),
            "region = ee.Geometry.Rectangle([xmin, ymin, xmax, ymax])",
        ]

    band_expr = (
        "[{}]".format(", ".join("'{}'".format(band) for band in request.source_bands))
        if request.source_bands
        else "None"
    )
    lines = [
        "import ee",
        "",
        "ee.Authenticate()",
        "ee.Initialize(project='{}')".format(request.project_id or "your-project-id"),
        "",
    ]
    lines.extend(region_lines)
    lines.append("")

    if request.source_type == "ImageCollection":
        lines.extend(
            [
                "collection = (",
                "    ee.ImageCollection('{}')".format(request.dataset_id or "YOUR/DATASET_ID"),
                "    .filterBounds(region)",
            ]
        )
        if request.start_date and request.end_date:
            lines.append(
                "    .filterDate('{}', '{}')".format(request.start_date, request.end_date)
            )
        if request.source_bands:
            lines.append("    .select({})".format(band_expr))
        lines.append(")")
        lines.append("")
        image_expression = _collection_to_image_expression("collection", request.reducer)
        if request.derived_product:
            image_expression = _derived_expression(
                image_expression,
                request.derived_product,
                request.source_bands,
                request.output_bands,
            )
        lines.append("image = {}".format(image_expression))
    else:
        lines.append("image = ee.Image('{}')".format(request.dataset_id or "YOUR/IMAGE_ID"))
        if request.source_bands:
            lines.append("image = image.select({})".format(band_expr))
        if request.derived_product:
            lines.append(
                "image = {}".format(
                    _derived_expression(
                        "image",
                        request.derived_product,
                        request.source_bands,
                        request.output_bands,
                    )
                )
            )

    lines.extend(
        [
            "image = image.clip(region)",
            "",
            "url = image.getDownloadURL({",
            "    'region': region,",
            "    'scale': {}, ".format(request.scale),
            "    'format': 'GEO_TIFF',",
        ]
    )
    if request.output_bands:
        output_band_expr = "[{}]".format(
            ", ".join("'{}'".format(band) for band in request.output_bands)
        )
        lines.append("    'bands': {}, ".format(output_band_expr))
    lines.extend(
        [
            "})",
            "",
            "# Download the GeoTIFF and add it to QGIS.",
            "# Optional: also load single-band analysis layers for each output band.",
        ]
    )

    return "\n".join(lines)


def download_image(
    request: DownloadRequest,
    progress_callback: ProgressCallback = None,
    cancel_callback: CancelCallback = None,
) -> DownloadResult:
    ee = ensure_earth_engine()
    _set_progress(progress_callback, 5)

    if not request.region_geojson:
        raise RuntimeError("The plugin could not resolve the region of interest.")

    _check_cancel(cancel_callback)
    try:
        ee.Initialize(project=request.project_id)
    except Exception as exc:
        raise RuntimeError(
            "Earth Engine is not initialized for this QGIS session. Click 'Authenticate' first."
        ) from exc

    _set_progress(progress_callback, 15)
    region = ee.Geometry(request.region_geojson)
    image = _build_image(ee, request, region)
    _check_cancel(cancel_callback)

    _set_progress(progress_callback, 45)
    params: Dict[str, Any] = {
        "region": region,
        "scale": request.scale,
        "format": "GEO_TIFF",
    }
    if request.output_bands:
        params["bands"] = request.output_bands

    url = image.getDownloadURL(params)
    _check_cancel(cancel_callback)

    _set_progress(progress_callback, 60)
    directory = os.path.dirname(request.output_path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    with urllib.request.urlopen(url, timeout=180) as response, open(
        request.output_path, "wb"
    ) as output_file:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            _check_cancel(cancel_callback)
            output_file.write(chunk)

    _write_band_descriptions(request.output_path, request.output_bands, request.band_labels)
    load_path = _build_named_vrt(request.output_path, request.output_bands, request.band_labels)
    generated_layers = _build_single_band_vrts(
        request.output_path,
        request.layer_name,
        request.output_bands,
        request.band_labels,
        request.load_individual_bands,
    )
    _set_progress(progress_callback, 100)
    return DownloadResult(
        output_path=request.output_path,
        load_path=load_path,
        layer_name=request.layer_name,
        generated_layers=generated_layers,
    )


def _build_image(ee, request: DownloadRequest, region):
    if request.source_type == "Image":
        image = ee.Image(request.dataset_id)
        if request.source_bands:
            image = image.select(request.source_bands)
        return _apply_derived_product(image, request).clip(region)

    collection = ee.ImageCollection(request.dataset_id).filterBounds(region)
    if request.start_date and request.end_date:
        collection = collection.filterDate(request.start_date, request.end_date)
    if request.source_bands:
        collection = collection.select(request.source_bands)

    image = _apply_reducer(ee, collection, request.reducer)
    image = _apply_derived_product(image, request)
    return image.clip(region)


def _apply_reducer(ee, collection, reducer: str):
    reducer_name = (reducer or "median").lower()

    if reducer_name == "median":
        return collection.median()
    if reducer_name == "mean":
        return collection.mean()
    if reducer_name == "mosaic":
        return collection.mosaic()
    if reducer_name == "mode":
        return collection.reduce(ee.Reducer.mode())
    if reducer_name == "first":
        return ee.Image(collection.first())

    raise RuntimeError("Unsupported reducer '{}'.".format(reducer))


def _collection_to_image_expression(collection_name: str, reducer: str) -> str:
    reducer_name = (reducer or "median").lower()

    if reducer_name == "median":
        return "{}.median()".format(collection_name)
    if reducer_name == "mean":
        return "{}.mean()".format(collection_name)
    if reducer_name == "mosaic":
        return "{}.mosaic()".format(collection_name)
    if reducer_name == "mode":
        return "{}.reduce(ee.Reducer.mode())".format(collection_name)
    if reducer_name == "first":
        return "ee.Image({}.first())".format(collection_name)

    return "{}.median()".format(collection_name)


def _apply_derived_product(image, request: DownloadRequest):
    if not request.derived_product:
        return image

    if len(request.source_bands) != 2:
        raise RuntimeError(
            "{} requires exactly two source bands, but got {}.".format(
                request.derived_product,
                len(request.source_bands),
            )
        )

    if request.derived_product in ("NDVI", "NDWI"):
        return image.normalizedDifference(request.source_bands).rename(request.output_bands[0])

    raise RuntimeError("Unsupported derived product '{}'.".format(request.derived_product))


def _derived_expression(
    image_expression: str,
    derived_product: str,
    source_bands: List[str],
    output_bands: List[str],
) -> str:
    if derived_product in ("NDVI", "NDWI") and len(source_bands) == 2:
        return (
            "{}.normalizedDifference(['{}', '{}']).rename('{}')".format(
                image_expression,
                source_bands[0],
                source_bands[1],
                output_bands[0],
            )
        )

    return image_expression


def _write_band_descriptions(
    output_path: str,
    output_bands: List[str],
    band_labels: List[str],
) -> None:
    if not output_bands:
        return

    try:
        from osgeo import gdal  # type: ignore
    except ImportError:
        return

    dataset = gdal.Open(output_path, gdal.GA_Update)
    if dataset is None:
        return

    band_count = dataset.RasterCount
    for index, output_band in enumerate(output_bands[:band_count], start=1):
        raster_band = dataset.GetRasterBand(index)
        if raster_band is None:
            continue

        label = band_labels[index - 1] if index - 1 < len(band_labels) else output_band
        raster_band.SetDescription(label)
        raster_band.SetMetadataItem("BAND_NAME", output_band)
        raster_band.SetMetadataItem("BAND_LABEL", label)

    dataset.FlushCache()
    dataset = None


def _build_named_vrt(
    output_path: str,
    output_bands: List[str],
    band_labels: List[str],
) -> str:
    if not output_bands:
        return output_path

    try:
        from osgeo import gdal  # type: ignore
    except ImportError:
        return output_path

    source_dataset = gdal.Open(output_path)
    if source_dataset is None:
        return output_path

    vrt_path = "{}.vrt".format(os.path.splitext(output_path)[0])
    vrt_dataset = gdal.Translate(
        vrt_path,
        source_dataset,
        options=gdal.TranslateOptions(format="VRT"),
    )
    source_dataset = None
    if vrt_dataset is None:
        return output_path

    band_count = vrt_dataset.RasterCount
    for index, output_band in enumerate(output_bands[:band_count], start=1):
        raster_band = vrt_dataset.GetRasterBand(index)
        if raster_band is None:
            continue

        label = band_labels[index - 1] if index - 1 < len(band_labels) else output_band
        raster_band.SetDescription(label)
        raster_band.SetMetadataItem("BAND_NAME", output_band)
        raster_band.SetMetadataItem("BAND_LABEL", label)
        color_interp = _suggest_color_interpretation(index, len(output_bands))
        if color_interp is not None:
            raster_band.SetColorInterpretation(color_interp)

    vrt_dataset.FlushCache()
    vrt_dataset = None
    return vrt_path


def _build_single_band_vrts(
    output_path: str,
    layer_name: str,
    output_bands: List[str],
    band_labels: List[str],
    enabled: bool,
) -> List[GeneratedLayer]:
    if not enabled or len(output_bands) <= 1:
        return []

    try:
        from osgeo import gdal  # type: ignore
    except ImportError:
        return []

    source_dataset = gdal.Open(output_path)
    if source_dataset is None:
        return []

    single_band_layers = []
    for index, output_band in enumerate(output_bands, start=1):
        label = band_labels[index - 1] if index - 1 < len(band_labels) else output_band
        safe_label = _safe_filename_fragment(label)
        single_vrt_path = "{}_{}.vrt".format(os.path.splitext(output_path)[0], safe_label)
        single_vrt = gdal.Translate(
            single_vrt_path,
            source_dataset,
            options=gdal.TranslateOptions(format="VRT", bandList=[index]),
        )
        if single_vrt is None:
            continue

        raster_band = single_vrt.GetRasterBand(1)
        if raster_band is not None:
            raster_band.SetDescription(label)
            raster_band.SetMetadataItem("BAND_NAME", output_band)
            raster_band.SetMetadataItem("BAND_LABEL", label)

        single_vrt.FlushCache()
        single_vrt = None
        single_band_layers.append(
            GeneratedLayer(
                path=single_vrt_path,
                name="{} - {}".format(layer_name, label),
            )
        )

    source_dataset = None
    return single_band_layers


def _suggest_color_interpretation(index: int, band_count: int):
    try:
        from osgeo import gdal  # type: ignore
    except ImportError:
        return None

    if band_count == 3:
        mapping = {
            1: gdal.GCI_RedBand,
            2: gdal.GCI_GreenBand,
            3: gdal.GCI_BlueBand,
        }
        return mapping.get(index)

    if band_count == 4:
        mapping = {
            1: gdal.GCI_RedBand,
            2: gdal.GCI_GreenBand,
            3: gdal.GCI_BlueBand,
            4: gdal.GCI_AlphaBand,
        }
        return mapping.get(index)

    return None


def _safe_filename_fragment(value: str) -> str:
    return "".join(
        character if character.isalnum() else "_"
        for character in value
    ).strip("_") or "band"
