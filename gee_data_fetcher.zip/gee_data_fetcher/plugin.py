import json
import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsMapLayerType,
    QgsProject,
    QgsRasterLayer,
    QgsTask,
    QgsWkbTypes,
)

try:
    from .dialog import GeeDataFetcherDialog
    from .gee_service import authenticate, download_image
except (ImportError, KeyError):
    from dialog import GeeDataFetcherDialog
    from gee_service import authenticate, download_image


class GeeDataFetcherPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.active_tasks = []

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        self.action = QAction(QIcon(icon_path), "GEE Data Fetcher", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GEE Data Fetcher", self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&GEE Data Fetcher", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        dialog = GeeDataFetcherDialog(self.iface.mainWindow())
        dialog.authenticate_button.clicked.connect(lambda: self._handle_authentication(dialog))
        dialog.download_button.clicked.connect(lambda: self._handle_download(dialog))
        dialog.exec_()

    def _handle_authentication(self, dialog: GeeDataFetcherDialog):
        dialog.set_status("Authenticating with Earth Engine...")
        dialog.set_busy(True)
        try:
            authenticate(dialog.project_id_edit.text().strip())
        except Exception as exc:
            self._push_message("Earth Engine authentication failed", str(exc), Qgis.Critical)
            dialog.show_error(str(exc))
        else:
            message = "Earth Engine is ready for project '{}'.".format(dialog.project_id_edit.text().strip())
            self._push_message("Earth Engine ready", message, Qgis.Success)
            dialog.set_status(message)
            dialog.save_settings()
        finally:
            dialog.set_busy(False)

    def _handle_download(self, dialog: GeeDataFetcherDialog):
        try:
            region_geojson = self._resolve_region_geojson(dialog.region_source_combo.currentText())
            request = dialog.build_request(region_geojson=region_geojson)
        except Exception as exc:
            dialog.show_error(str(exc))
            return

        dialog.set_busy(True)
        dialog.set_status("Preparing Earth Engine session...")
        try:
            authenticate(request.project_id)
        except Exception as exc:
            dialog.set_busy(False)
            self._push_message("Earth Engine authentication failed", str(exc), Qgis.Critical)
            dialog.show_error(str(exc))
            return

        dialog.save_settings()
        dialog.set_status("Starting download task...")
        self._push_message(
            "Earth Engine download started",
            "Fetching '{}' as a GeoTIFF.".format(request.dataset_id),
            Qgis.Info,
        )

        def task_runner(task, request):
            return download_image(
                request,
                progress_callback=task.setProgress,
                cancel_callback=task.isCanceled,
            )

        def on_finished(exception, result=None):
            dialog.set_busy(False)
            if exception is not None:
                self._push_message("Earth Engine download failed", str(exception), Qgis.Critical)
                dialog.show_error(str(exception))
                return

            layer = QgsRasterLayer(result.load_path, result.layer_name)
            if not layer.isValid():
                message = (
                    "The raster downloaded successfully, but QGIS could not load the layer: "
                    "{}".format(result.load_path)
                )
                self._push_message("Raster load failed", message, Qgis.Warning)
                dialog.show_error(message)
                return

            QgsProject.instance().addMapLayer(layer)
            loaded_analysis_layers = 0
            for generated_layer in result.generated_layers:
                analysis_layer = QgsRasterLayer(generated_layer.path, generated_layer.name)
                if analysis_layer.isValid():
                    QgsProject.instance().addMapLayer(analysis_layer)
                    loaded_analysis_layers += 1

            message = "Downloaded '{}' and added it to the project.".format(result.layer_name)
            if loaded_analysis_layers:
                message = "{} Added {} single-band analysis layer(s).".format(
                    message,
                    loaded_analysis_layers,
                )
            self._push_message("Raster added", message, Qgis.Success)
            dialog.set_status(message)

        task = QgsTask.fromFunction(
            "Download {} from Earth Engine".format(request.layer_name),
            task_runner,
            on_finished=on_finished,
            request=request,
        )
        self.active_tasks.append(task)
        task.taskCompleted.connect(lambda: self._release_task(task))
        task.taskTerminated.connect(lambda: self._release_task(task))
        QgsApplication.taskManager().addTask(task)

    def _release_task(self, task):
        if task in self.active_tasks:
            self.active_tasks.remove(task)

    def _resolve_region_geojson(self, region_source: str):
        if region_source == "Selected polygons from active layer":
            return self._selected_polygons_geojson()
        return self._current_extent_geojson()

    def _current_extent_geojson(self):
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()
        source_crs = canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(
            source_crs,
            QgsCoordinateReferenceSystem("EPSG:4326"),
            QgsProject.instance(),
        )
        extent_wgs84 = transform.transformBoundingBox(extent)
        return {
            "type": "Polygon",
            "coordinates": [[
                [extent_wgs84.xMinimum(), extent_wgs84.yMinimum()],
                [extent_wgs84.xMaximum(), extent_wgs84.yMinimum()],
                [extent_wgs84.xMaximum(), extent_wgs84.yMaximum()],
                [extent_wgs84.xMinimum(), extent_wgs84.yMaximum()],
                [extent_wgs84.xMinimum(), extent_wgs84.yMinimum()],
            ]],
        }

    def _selected_polygons_geojson(self):
        layer = self.iface.activeLayer()
        if layer is None:
            raise RuntimeError("No active layer is selected.")
        if layer.type() != QgsMapLayerType.VectorLayer:
            raise RuntimeError("The active layer must be a polygon vector layer.")
        if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.PolygonGeometry:
            raise RuntimeError("The active layer must contain polygon geometry.")
        if layer.selectedFeatureCount() == 0:
            raise RuntimeError("Select one or more polygon features first.")

        geometries = []
        for feature in layer.selectedFeatures():
            geometry = feature.geometry()
            if geometry and not geometry.isEmpty():
                geometries.append(QgsGeometry(geometry))

        if not geometries:
            raise RuntimeError("The selected features do not contain valid geometry.")

        merged = QgsGeometry.unaryUnion(geometries)
        transform = QgsCoordinateTransform(
            layer.crs(),
            QgsCoordinateReferenceSystem("EPSG:4326"),
            QgsProject.instance(),
        )
        merged.transform(transform)
        return json.loads(merged.asJson())

    def _push_message(self, title: str, text: str, level: Qgis.MessageLevel):
        self.iface.messageBar().pushMessage(title, text, level=level, duration=6)
